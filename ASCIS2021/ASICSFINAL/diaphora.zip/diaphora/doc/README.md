## Documentation

This directory contains all the documentation files for the Diaphora project. Currently, it contains the official documentation
"diaphora_doc.pdf" and a copy of Alex Ionescu's blog talking about a use case of Diaphora.
